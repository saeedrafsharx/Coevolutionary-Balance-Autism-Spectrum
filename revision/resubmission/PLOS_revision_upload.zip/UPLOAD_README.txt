PONE-D-26-34219 revision files

Revised manuscript: manuscript_submission.pdf (clean, captions inline).
Manuscript source: manuscript_source.zip; entry file main.tex.
Manuscript with changes: manuscript_marked.pdf (original numerical tables omitted
from deletion display; replacement tables included).
Response to Reviewers: response_to_reviewers.pdf (locations reference clean PDF).
Supporting Information: supporting_information.pdf = S1 Appendix;
S2_Data.zip = S2 Data; S3_Code.zip = S3 Code.
Figures: Fig1.tif through Fig11.tif, separately, matching numbered captions.

The paper and response clearly attribute voxelwise fALFF to downloaded PCP/C-PAC
derivatives. Historical denominator/filter-order details are not independently
verified and are transparently disclosed. No provider confirmation is invented.
Files are prepared for upload; nothing has been submitted automatically.
