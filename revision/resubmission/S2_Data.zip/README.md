# S2 Data
Complete revision results and analysis tables. No original MRI images are redistributed.
features/ contains the common raw feature table and analysis covariates/clinical scores.
statistics/ contains final group, clinical, null and prediction results.
harmonized_features/ contains checked ComBat sensitivity features.
continuity/ preserves original-export reproduction separately from revision findings.
ml_feature_selection/ contains the explicitly exploratory post-baseline extension,
including all inner candidates, selected names and aligned out-of-fold predictions.
control_nulls/ contains the separate healthy-male baseline (71 controls).
provenance/, diagnostics/, frozen_design/ document inputs, scope and model checks.
figure_source/ contains additional descriptive projection coordinates.
Control-only q values and all-participant q values have different declared families;
the revised main text uses the all-560 participant/pipeline/null family.
S3 Code supplies execution instructions. The main Methods describe unresolved
historical fALFF denominator/filtering provenance; completeness is not validation
of that historical branch. INDEX_SHA256.csv records every payload file.
