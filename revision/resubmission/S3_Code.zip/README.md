# S3 Code: exact revision analysis release

The executable analysis, audit, plot and reporting source is in Codes/.
Frozen participant/ROI definitions and revision-stage analysis specifications are
in revision/analysis_plan/. Historical acquisition and analysis notebooks are
retained for audit; the revised feature/stats scripts define current results.

Sequence: stage-1 acquisition/coverage QC -> stage-1b review and frozen design ->
abide_stage2_run.py (or corresponding notebook) -> documented statistics repair
when needed -> complete_original_classifiers.py -> run_ml_feature_selection.py
-> report_ml_feature_selection.py. Read each script's top-level configuration
and command arguments before execution. Source imaging is not included here.

Input Kaggle datasets: abide-full-derivatives-dataset/abide_revision and
abide-metadata-patch/abide_metadata_patch_local_v2. ABIDE/PCP retains source images.
PCP/C-PAC computed the downloaded voxelwise fALFF maps. Local code extracts ROI
means and computes FC, graph features and statistics; it does not recompute the
voxelwise fALFF denominator. Exact historical denominator/filter-order details
remain unverified and are disclosed in the main Methods, not asserted as known.

The five-model classifier analysis is the baseline. Expanded feature selection
is a separate exploratory follow-up specified after baseline results were seen.
It must not overwrite the baseline or be treated as independent validation.
S2 Data supplies complete results, selection names, inner candidates, predictions,
covariates and provenance. Directory paths in scripts refer to the full project
layout; reconstruct those paths from S2 where rebuilding reports locally.
The frozen plans are historical records and do not supersede the final Methods.

Software: Python 3; NumPy 1.26.4, pandas 2.1.4, SciPy 1.11.4,
statsmodels 0.15.0, neuroCombat 0.2.12, scikit-learn 1.9.1,
XGBoost CPU 3.4.1, matplotlib 3.6.3. S2 contains audit version records.
Publication plots use Arial. build_resubmission_exhibits.py regenerates figures
and tables from the verified results. Manuscript LaTeX is supplied separately
as manuscript_source.zip with the submission, not mixed with private review letters.
